import 'package:flutter/material.dart';
import 'package:flutter_page/main_page.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Page1(),
  ));
}
